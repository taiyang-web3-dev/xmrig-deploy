#!/bin/bash
echo "Installing XMRig Miner..."
bash <(curl -s https://raw.githubusercontent.com/taiyang-web3-dev/xmrig-deploy/main/scripts/install.sh)
echo "Installation complete!"
read -p "Press Enter to exit..."
