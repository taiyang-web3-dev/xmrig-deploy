#!/bin/bash
~/miner-config/scripts/stop.sh
echo "Miner stopped!"
read -p "Press Enter to exit..."
