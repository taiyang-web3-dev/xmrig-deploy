#!/bin/bash
~/miner-config/scripts/status.sh
read -p "Press Enter to exit..."
