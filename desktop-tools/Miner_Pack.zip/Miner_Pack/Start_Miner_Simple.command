#!/bin/bash
echo "Starting XMRig..."
cd ~/xmrig
./xmrig --config=config.json
